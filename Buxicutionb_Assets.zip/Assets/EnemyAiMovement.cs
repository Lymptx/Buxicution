using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class EnemyAiMovement : MonoBehaviour
{
    NavMeshAgent myAganet;

    public Transform Player;
    public LayerMask playerLayer;

    public float playerCheckRadius;
    public float explosionRadius;

    public float destroyWaitTime;
    public float playerDamageTime;

    public float bombEenemyDamage;

    SpriteRenderer spriteRenderer;
    public Animator animator;
    public EnemyLives livesM;

    bool isBooming; //use please, damit nicht jedes frame die update animation gecallt wird... und so 
    bool tookDamage;

    public bool enemyActive = true;

    bool isExploding;

    public float hitAnimationDuration;



    // Start is called before the first frame update
    void Start()
    {



        myAganet = GetComponent<NavMeshAgent>();
        myAganet.updateRotation = false;
        myAganet.updateUpAxis = false;

        spriteRenderer = GetComponent<SpriteRenderer>();

        StartSpawn();
    }


    IEnumerator WaitAnimationTime()
    {
        yield return new WaitForSeconds(1); //The camera zooms for 1 sec
        StartWalk();
    }



    // Update is called once per frame
    void Update()
    {
        if(enemyActive)
        {
            myAganet.SetDestination(Player.position);

            if (Physics2D.OverlapCircle(transform.position, playerCheckRadius, playerLayer))
            {
                //player is in explosion range 
                if (!isExploding)
                {
                    isExploding = true; //damit das nur einmal gecallt wird. 
                    GiveBombDieDamage();
                }
                

            }

            if (!Physics2D.OverlapCircle(transform.position, playerCheckRadius, playerLayer) && myAganet.isStopped)
            {
                //not spotted player
                spriteRenderer.color = Color.white;
            }

            Rotate();
        }
    }

    public void GiveBombDieDamage()
    {
        //call the function which is onb the lives manager. this then calles startEnemyBlowUp for all the animations and damageing the player
        livesM.DamageEnemy(50);
    }

    public void StartEnemySelfBlowUp()
    {
        //spriteRenderer.color = Color.red;
        myAganet.isStopped = true;

        

        StartCoroutine(WaitForPlayer());
        StartCoroutine(destroyBug());

        //start the boom animation
        StartBoom();
    }

    void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(transform.position, explosionRadius);
    }



    IEnumerator WaitForPlayer ()
    {
        yield return new WaitForSeconds(playerDamageTime);

        FindObjectOfType<Audio_Manager>().Play_("BombExplosion");

        //if player is still in the range of the explosion efffect
        if (Physics2D.OverlapCircle(transform.position, explosionRadius, playerLayer))
        {
            //spotted player, damage the player
            TakeDamage();

        } 
    }

    IEnumerator destroyBug ()
    {
        yield return new WaitForSeconds(destroyWaitTime);

        //Spawn A Pickup
        //FindObjectOfType<PickupSpawner>().SpawnPickup(transform.position);

        Destroy(gameObject);


        //livesM.DamageEnemy(50);
        //combatRaumManager = FindObjectOfType<CombatRaumManager>();
        //combatRaumManager.BombDied();

        ////destroy
        //Destroy(gameObject);
    }



    void TakeDamage ()
    {            

        if (!tookDamage)
        {
            tookDamage = true;

            //Player.gameObject.GetComponent<SpriteRenderer>().color = Color.red;
            Player.gameObject.GetComponent<LivesManager>().ChangePlayerLives(-bombEenemyDamage);
            //Debug.LogError("Took Damage");
        }
        
    }


    void Rotate ()
    {
        Vector2 moveDirection = (transform.position - Player.transform.position);
        Quaternion rotation = Quaternion.LookRotation(Vector3.forward, moveDirection);
        transform.rotation = rotation;
    }


    void StartSpawn()
    {
        //animator.SetBool("walk", true);
        animator.Play("Spider_Spawn");
    }

    void StartWalk()
    {
        //animator.SetBool("walk", true);
        animator.Play("Spider_Walk");
    }

    public void StartHit()
    {
        animator.Play("Spider_Hit");
    }

    void StartBoom()
    {
        if(!isBooming)
        {
            isBooming = true;

            animator.Play("Spider_Boom");   
            //animator.SetBool("boom", true);

            //Debug.LogError(animator.GetBool("boom"));
        }

        isBooming = true;

    }


    public void setEnemyActiveState(bool newState)
    {
        enemyActive = newState;
    }

    IEnumerator waitAfterHit ()
    {
        yield return new WaitForSeconds(hitAnimationDuration);

        StartWalk();
    }
}
