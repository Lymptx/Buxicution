using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class HealthBarManager : MonoBehaviour
{
    public LivesManager livesManager;
    public BossLives bossLives;
    public Text BosHealthText;

    public float Lerptime = 1f;
    public float BarLength = 1f;

    public float maxLives;

    public GameObject healthBarSprite;

    public bool isBossHealthBar;


    private void Update()
    {
        //Debug.Log("Before" + livesManager.lives_before);
        //Debug.Log("After" + livesManager.lives_after);

        //BarLength = Mathf.Lerp(livesManager.lives_before, livesManager.lives_after, Lerptime * Time.deltaTime);

        if (!isBossHealthBar)
        {
            //Is the Player
            BarLength = livesManager.currentLives / maxLives;
        } else
        {
            //Is the boss
            BarLength = bossLives.totalLives / maxLives;
            if(bossLives.totalLives * 100 / maxLives == 100)
            {
                BosHealthText.text = (bossLives.totalLives * 100 / maxLives).ToString("F0");
            } else
            {
                BosHealthText.text = (bossLives.totalLives * 100 / maxLives).ToString("F1");
            }
            
        }

        CalculateBarLength();

        //Debug.Log(BarLength);
    }

    void CalculateBarLength()
    {
        healthBarSprite.transform.localScale = new Vector3(BarLength, 1f, 0f);

        
    }
}
