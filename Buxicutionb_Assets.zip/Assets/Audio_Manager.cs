using UnityEngine.Audio;
using System;
using UnityEngine;

public class Audio_Manager : MonoBehaviour
{
    public Sound[] sounds;

    public static Audio_Manager instance;

    private void Awake()
    {
        //Check if there is an Audiomanager in the scene already
        if (instance == null)
            instance = this;
        else
        {
            //Then destroy the second one
            Destroy(gameObject);
            return;
        }

        //Make the Audiomanager persist between Scenes
        DontDestroyOnLoad(gameObject);

        foreach (Sound s in sounds)
        {
            s.source = gameObject.AddComponent<AudioSource>();
            s.source.clip = s.clip;

            s.source.volume = s.volume;
            s.source.pitch = s.pitch;
            s.source.loop = s.loop;

            s.source.outputAudioMixerGroup = s.group;
        }
    }

    private void Start()
    {
        Play_("Theme");
    }

    public void Play_(string name)
    {
        Sound s = Array.Find(sounds, sound => sound.name == name);
        if (s == null)
        {
            Debug.LogError("Der Sound: " + name + " wurde nicht gefunden!!! :(:(:(");
            return;
        }
        s.source.Play();
    }
}
