using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine;

public class LoadNxtLV : MonoBehaviour
{
    public Levelloader levelloader;

    private void OnTriggerEnter2D(Collider2D collision)
    {

        //Wenn es eh nicht der Boss ist. 

        if (SceneManager.sceneCountInBuildSettings - 1 == SceneManager.GetActiveScene().buildIndex)
        {
            PlayerPrefs.SetInt("CompletedGame", 1);
            PlayerPrefs.SetInt("CurrentLevel", 1);
            levelloader.StartSceneTransition(0);
        }
        else
        {
            PlayerPrefs.SetInt("CurrentLevel", SceneManager.GetActiveScene().buildIndex + 1);
            levelloader.StartSceneTransition(SceneManager.GetActiveScene().buildIndex + 1);
        }

    }
}
