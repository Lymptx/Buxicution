using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PauseMenu : MonoBehaviour
{
    public GameObject PlayerUI;
    public GameObject PauseUI;

    public SettingsManager settingsScript;

    public void OpenPauseMenu()
    {
        settingsScript.ChangeDifficultySettingsUp();

        PlayerUI.SetActive(false);
        PauseUI.SetActive(true);
        Time.timeScale = 0;
    }

    public void ClosePauseMenu()
    {
        //Play the sound
        FindObjectOfType<Audio_Manager>().Play_("ButtonPress");

        PlayerUI.SetActive(true);
        PauseUI.SetActive(false);
        Time.timeScale = 1;
    }
}
