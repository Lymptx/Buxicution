using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class DiedMenu : MonoBehaviour
{
    public GameObject DiedPanel;

    public void PlayerDied ()
    {
        DiedPanel.SetActive(true);

        StartCoroutine(WaitForLevelRestart());
    }

    IEnumerator WaitForLevelRestart ()
    {
        yield return new WaitForSeconds(3f);

        //Restart Level
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);

    }
}
