using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyBullet : MonoBehaviour
{
    public LayerMask ShildLayer;
    public Rigidbody2D rb;
    public BulletManager bulletManager;
    //public float BounceVel;

    [Header("TEST")]
    public bool haveStartVel;

    private void Start()
    {
        if (haveStartVel)
        {
            rb.velocity = new Vector2(0, -10);
        }       
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.collider.gameObject.layer != ShildLayer)
        {
            DestroyBullet();
            bulletManager.DestroyShield();
            bulletManager.StartNewShieldCorutine();
        }
    }

    void BounceBullet()
    {
        rb.velocity = -rb.velocity;
    }

    void DestroyBullet()
    {
        Destroy(gameObject, 0);
    }
}
