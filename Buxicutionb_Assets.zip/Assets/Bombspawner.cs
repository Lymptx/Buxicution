using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bombspawner : MonoBehaviour
{
    public float spawnTime;


    public float simpleSpawnTime;
    public float normalSpawnTime;
    public float nighmareSpawnTime;

    public GameObject bombEnemyPrefab;

    public bool isSpawning;
    public bool isTutorialLevel;

    //Managing stuff
    public CombatRaumManager combatRaumManager;
    public float inactiveTime;



    [Header("Referenzen f�r die Bombe")]
    public Transform Player;

    public GameObject firstBomb;
    bool firstBombSpawned;


    private void Start()
    {
        combatRaumManager = FindObjectOfType<CombatRaumManager>();

        isSpawning = true;

        //Spawn the first bomb, but wait for its activation
        SpawnFirstBomb();
        StartCoroutine(WaitForActivation());
    }



    IEnumerator WaitForActivation() //Does not start, while the camera is zooming
    {
        yield return new WaitForSeconds(inactiveTime);

        ActivateFirstBomb();

    }

    void ActivateFirstBomb()
    {
        firstBomb.GetComponent<EnemyAiMovement>().setEnemyActiveState(true);

        //Start the coroutine to spawn a new bomb
        StartCoroutine(WaitForNewBomb());
    }



    void SpawnFirstBomb ()
    {
        //if this is the first bom that spawned;
        GameObject enemy = Instantiate(bombEnemyPrefab, transform.position, Quaternion.identity);
        EnemyAiMovement bombScript = enemy.GetComponent<EnemyAiMovement>();
        bombScript.Player = Player;

        firstBomb = enemy;
        bombScript.setEnemyActiveState(false); //Because it should stay disabled a bit more

        //combatRaumManager.EnemySpawned(); (Auch Zeile 81) Wenn wir wollen, dass es aufh�rt zu spawnen, sobald nur noch Bomben leben auskommentiert lasen
        combatRaumManager.BombSpawned();

        if (isTutorialLevel)
        {
            //Stop after spawning the first bomb
            StopSpawning();
        }
    }




    void SpawnNewBomb ()
    {
        GameObject enemy = Instantiate(bombEnemyPrefab, transform.position, Quaternion.identity);
        EnemyAiMovement bombScript = enemy.GetComponent<EnemyAiMovement>();
        bombScript.Player = Player;
        bombScript.setEnemyActiveState(true);


        //combatRaumManager.EnemySpawned(); (Auch Zeile 67) Wenn wir wollen, dass es aufh�rt zu spawnen, sobald nur noch Bomben leben auskommentiert lasen
        combatRaumManager.BombSpawned();

        StartCoroutine(WaitForNewBomb());
    }



    IEnumerator WaitForNewBomb ()
    {
        yield return new WaitForSeconds(spawnTime);

        if (isSpawning)
        {
            SpawnNewBomb();
        }        
    }


    public void StopSpawning()
    {
        isSpawning = false;
        StopAllCoroutines();
    }


    private void Update()
    {
        if (PlayerPrefs.GetInt("Difficulty") == 1)
        {
            spawnTime = simpleSpawnTime;


        }
        else if (PlayerPrefs.GetInt("Difficulty") == 2)
        {
            spawnTime = normalSpawnTime;


        }
        else if (PlayerPrefs.GetInt("Difficulty") == 3)
        {
            spawnTime = nighmareSpawnTime;
        }
    }
} 
