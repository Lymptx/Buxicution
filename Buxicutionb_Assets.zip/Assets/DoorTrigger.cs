using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DoorTrigger : MonoBehaviour
{
    public bool isOpen; //leave on false if it is an exit door

    public CombatDoor combatDoor;

    public CombatRaumManager combatRaumManager;

    public int RaumIndex;




    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.layer == 7 || collision.gameObject.layer == 3) //Player oder Schild
        {
            //The player has triggered the doors opening
            if (isOpen)
            {
                combatDoor.OpenDoor();
                
                
            } else
            {
                combatDoor.CloseDoor();

                //Entered a t[r closed trigger, = entered new combat room
                combatRaumManager.EnteredCombatRoom(RaumIndex);
                gameObject.SetActive(false);
            }
        }
    }
}
