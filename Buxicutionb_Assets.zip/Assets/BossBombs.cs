using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BossBombs : MonoBehaviour
{

    public float spawnTime;

    public float simpleSpawnTime;
    public float normalSpawnTime;
    public float nighmareSpawnTime;

    public GameObject bombEnemyPrefab;
    public bool isSpawning = false;    //

    public Transform Player;
    public Transform bombSpawnPos;



    ////-------------bombe
    public void SpawnNewBomb()
    {

        Debug.Log("1");
        GameObject enemy = Instantiate(bombEnemyPrefab, bombSpawnPos.position, Quaternion.identity);
        EnemyAiMovement bombScript = enemy.GetComponent<EnemyAiMovement>();
        bombScript.Player = Player.transform;
        bombScript.setEnemyActiveState(true);


        //combatRaumManager.EnemySpawned(); (Auch Zeile 67) Wenn wir wollen, dass es aufh�rt zu spawnen, sobald nur noch Bomben leben auskommentiert lasen
        //combatRaumManager.BombSpawned();

        StartCoroutine(WaitForNewBomb());

        Debug.Log("2");
    }



    IEnumerator WaitForNewBomb()
    {
        Debug.Log("dadadadad");
        yield return new WaitForSeconds(spawnTime);

        SpawnNewBomb();
        Debug.Log("3");


    }

    void StopSpawning ()
    {
        isSpawning = false;
        StopAllCoroutines();
    }






    private void Update()
    {
        if (PlayerPrefs.GetInt("Difficulty") == 1)
        {
            spawnTime = simpleSpawnTime;


        }
        else if (PlayerPrefs.GetInt("Difficulty") == 2)
        {
            spawnTime = normalSpawnTime;


        }
        else if (PlayerPrefs.GetInt("Difficulty") == 3)
        {
            spawnTime = nighmareSpawnTime;
        }
    }
}
