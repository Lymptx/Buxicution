using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player_Movement : MonoBehaviour
{
    [Header("Referenzen")]
    public Rigidbody2D rb;
    public Camera cam;
    public GameObject PewPewPrefab;

    [Header("Einstellungen")]
    public bool HasPlayerControl;

    [Header("Move")]
    public float MovementSpeed;
    public float MovementSmoothing;

    [Header("Dash")]
    public float DashAmmount;
    public float DashCooldown;
    public float TrailSpeed;
    bool dash = true;

    SpriteRenderer spriteRenderer;

    Vector2 Dashforce;
    Vector2 movement;
    Vector2 mousePos;
    Vector2 Null_Vector = Vector2.zero;
    [HideInInspector]
    public Vector2 lookDir;



    private void Start()
    {
        spriteRenderer = gameObject.GetComponent<SpriteRenderer>();

        SetPlayerControl(true);
    }

    private void Update()
    {
        if (HasPlayerControl)
        {
            movement.x = Input.GetAxisRaw("Horizontal");
            movement.y = Input.GetAxisRaw("Vertical");

            mousePos = cam.ScreenToWorldPoint(Input.mousePosition);
            if (Input.GetKeyDown(KeyCode.Space))
            {
                Dash();
            }

            CheckIfTrail();
        }
        
    }

    private void FixedUpdate()
    {
        if (HasPlayerControl)
        {
            Move();
            Rotate();
        }

    }

    void Move()
    {
        // Move the character by finding the target velocity
        Vector2 targetVelocity = new Vector2(movement.x, movement.y).normalized * MovementSpeed;

        // And then smoothing it out and applying it to the character
        rb.velocity = Vector2.SmoothDamp(rb.velocity, targetVelocity, ref Null_Vector, MovementSmoothing);
    }

    void Dash()
    {
        if (dash)
        {
            //Play Sound
            FindObjectOfType<Audio_Manager>().Play_("PlayerDash");


            //Look Direction und Move Direction berechnen
            lookDir = Calculate_LookDir();
            Vector2 MoveDir = new Vector2(movement.x, movement.y).normalized;

            //Falls sich der Player bewegt
            if (movement != Vector2.zero)
            {
                Dashforce = MoveDir * DashAmmount;
                //In Richtung der Bewegung dashen
                rb.AddForce(Dashforce);
            }
            else
            {
                Dashforce = lookDir * DashAmmount;
                //In Richtung der Maus dashen
                rb.AddForce(Dashforce);
            }

            //Ability zu dashen sperren
            dash = false;
            //spriteRenderer.color = Color.red;
            StartCoroutine(Dashcooldown());
        }
    }

    void CheckIfTrail()
    {
        if (rb.velocity.magnitude >= TrailSpeed)
        {
            gameObject.GetComponent<TrailRenderer>().emitting = true;
            Physics2D.IgnoreLayerCollision(7, 9, true);
            Physics2D.IgnoreLayerCollision(3, 9, true);
        }
        else
        {
            gameObject.GetComponent<TrailRenderer>().emitting = false;
            Physics2D.IgnoreLayerCollision(7, 9, false);
            Physics2D.IgnoreLayerCollision(3, 9, false);
        }
    }

    IEnumerator Dashcooldown()
    {
        yield return new WaitForSeconds(DashCooldown);
        dash = true;
        spriteRenderer.color = Color.white;
    }

    void Rotate()
    {
        lookDir = Calculate_LookDir();
        float angle = Mathf.Atan2(lookDir.y, lookDir.x) * Mathf.Rad2Deg - 90f;
        rb.rotation = angle;
    }

    Vector2 Calculate_LookDir()
    {
        Vector2 direction = (mousePos - rb.position).normalized;
        return direction;
    }

    //public void GetNewPewPew()
    //{
    //    Instantiate(PewPewPrefab, gameObject.transform);
    //}

    public void SetPlayerControl (bool HasControl)
    {
        HasPlayerControl = HasControl;

        //values to zero
        movement.x = 0f;
        movement.y = 0f;
        movement.y = 0f;
        rb.velocity = Vector2.zero;
        

        //if(!HasPlayerControl)
        //{
        //    rb.freezeRotation = true;
        //} else
        //{
        //    rb.freezeRotation = false;
        //}
    }



}


