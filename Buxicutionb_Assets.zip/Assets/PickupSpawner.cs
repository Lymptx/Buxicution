using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PickupSpawner : MonoBehaviour
{
    public GameObject pickupPrefab;

    public static PickupSpawner instance;

    //Instancing
    private void Awake()
    {
        //Check if there is an Audiomanager in the scene already
        if (instance == null)
            instance = this;
        else
        {
            //Then destroy the second one
            Destroy(gameObject);
            return;
        }

        //Make the Audiomanager persist between Scenes
        DontDestroyOnLoad(gameObject);
    }

        public void SpawnPickup(Vector2 spawnPos)
    {
        Instantiate(pickupPrefab, spawnPos, Quaternion.identity);
    }
}
