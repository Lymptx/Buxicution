using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class SniperEnemy : MonoBehaviour
{
    NavMeshAgent myAgent;

    public GameObject playerO;
    public LayerMask groundLayer;
    public LayerMask allesAusserGround;
    public LayerMask allesAu�erEenemy;
    public float snipingDistance; //The distance from where it starts sniping

    [Header("Bools")]
    public bool isAiming;
    public bool PlayerInSight;
    public bool playerOutOfDistance;

    public bool isMoving;
    public bool isLocking; //Der Sstate, wo nach einer Zeit der Strahl einf an der Stelle bleibt
    public bool isChasing; //Der State, wo er stehenbleibt und den Player mit dem d�nnen Strahl verfolgt

    public float verfolgTime; //Die zwei Sec, wo er den player verfolgt
    public float lockTime; // locks onto the position
    public LineRenderer aimLine;
    public LineRenderer thickLine;
    public float LaserFlashTime;

    public Transform[] wayPoints;
    public int currentWayPointIndex;


    private Transform lastPlayerPos;

    public float sniperDamage;

    public Animator animator;

    CombatRaumManager combatRaumManager;

    public bool enemyActive = false;
    public float inactiveTime;
    public float camZoomTime;

    public float hitAnimationDuration;
    bool isPlayingHitAnimation = false;

    // Start is called before the first frame update
    void Start()
    {

        myAgent = GetComponent<NavMeshAgent>();
        myAgent.updateRotation = false;
        myAgent.updateUpAxis = false;

        isMoving = true;

        //Spawning
        StartSpawn();
        StartCoroutine(WaitForWalkTime());
        combatRaumManager = FindObjectOfType<CombatRaumManager>();
        combatRaumManager.EnemySpawned();
        StartCoroutine(ActivateEnemy());
    }
    IEnumerator WaitForWalkTime ()
    {
        yield return new WaitForSeconds(camZoomTime); //The camera zooms tot the full view for 1 sec

        //stop playing the spawn anim and start playing walk
        StartWalk();
    }

    IEnumerator ActivateEnemy()
    {
        yield return new WaitForSeconds(inactiveTime);

        enemyActive = true;
    }


    // Update is called once per frame
    void Update()
    {
        if (enemyActive)
        {
            //Move the navmesh agent
            if (isMoving)
            {
                myAgent.SetDestination(wayPoints[currentWayPointIndex - 1].position);
            }
            //myAgent.SetDestination(playerO.transform.position);

            if (Vector2.Distance(gameObject.transform.position, playerO.transform.position) > snipingDistance)
            {
                //Plazer is outside sniping distance
                PlayerOutsightDistance();
            }
            else
            {
                playerOutOfDistance = false;
            }




            //Check is player is in sight
            if (Physics2D.Linecast(gameObject.transform.position, playerO.transform.position, groundLayer))
            {
                //is there is a collier between the player and this enemy. (or the excapt opposite, see later with debugging)
                PlayerInSight = false;

                if (isChasing && !isLocking)
                {
                    ResetSniperBools();
                }

            }

            if (!Physics2D.Linecast(gameObject.transform.position, playerO.transform.position, groundLayer))
            {
                //is there is a collier between the player and this enemy. (or the excapt opposite, see later with debugging)
                PlayerInSight = true;
            }

            //Start Aming
            if (playerOutOfDistance && PlayerInSight) //also check later if the player is in sight
            {
                if (!isLocking)
                {
                    StartAming();
                }

            }
            else if (playerOutOfDistance && isAiming || PlayerInSight && isAiming)
            {
                //if currently aming but player moves out of sight
                StopAming();
            }


            //Check if the next waypoint is reached
            if ((gameObject.transform.position - wayPoints[currentWayPointIndex - 1].position).sqrMagnitude < 0.6f)
            {
                //Player has reached th next checkpoints
                
                GetNewWayPoint();
            }



            Rotate();
        }
               

    }


    //Draw a circle    void OnDrawGizmosSelected()
    void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(transform.position, snipingDistance);
    }

    void PlayerOutsightDistance () 
    {
        playerOutOfDistance = true;
    }

    void StartAming () 
    {
        StartAim();
        
        aimLine.enabled = true;
        
        isAiming = true;
        myAgent.isStopped = true;
        isMoving = false;


        lastPlayerPos = playerO.transform;
        //Line 
        DrawD�nneLinie();

        if (!isChasing)
        {
            StartCoroutine(StartSipingCountdown());
        }
    }


    void DrawD�nneLinie () 
    {
        //Set the linerenderer

        Vector3 dir = new Vector3();
        dir = (lastPlayerPos.position - gameObject.transform.position).normalized;

        Vector3 wallPoint;

        RaycastHit2D hit = Physics2D.Raycast(transform.position, dir, 100, groundLayer);
        //Debug.Log(dir);
        //Debug.Log(hit);
        //Debug.Log(hit.collider.gameObject.layer);


        wallPoint = hit.point;

        aimLine.SetPosition(0, gameObject.transform.position);
        aimLine.SetPosition(1, wallPoint);

        // If it hits something...
        if (hit.collider != null)
        {
            //hit te wall
            
        } else
        {
            Debug.LogError(" CANNOT HIT WALL");
        }

        
    }



    void StopAming ()
    {
        aimLine.enabled = false;

        isAiming = false;
        myAgent.isStopped = false;
        isMoving = true;

        StartWalk();
    }

    void GetNewWayPoint () 
    {
        //int new_ = Random.Range(0, wayPoints.Length);
        //currentWayPointIndex = new_;



        if (currentWayPointIndex < wayPoints.Length)
        {
            currentWayPointIndex++;

        } else
        {
            //if it is the last waypoint, then go back to the first one. 
            currentWayPointIndex = 1;

        }
    }


    IEnumerator StartSipingCountdown ()
    {
        isChasing = true;

        yield return new WaitForSeconds(verfolgTime);

        isAiming = false;

        StartLock();
    }

    void StartLock ()
    {
        isAiming = false;

        ///do some raycast work
        Vector2 lockPointEnd;

        Vector3 dir = new Vector3();
        dir = (lastPlayerPos.position - gameObject.transform.position).normalized;

        RaycastHit2D hit = Physics2D.Raycast(transform.position, dir, 100, groundLayer);

        //textPoint.transform.position = hit.point;
        lockPointEnd = hit.point;

        lastPlayerPos = playerO.transform;
        //raycast end----------

        aimLine.SetPosition(1, lockPointEnd);

        if (!isLocking)
        {
            StartCoroutine(StartLockTime(lockPointEnd, dir));
        }        

        isLocking = true;
    }

    IEnumerator StartLockTime(Vector2 endPoint, Vector3 dir)
    {
        //isLocking = true;

        yield return new WaitForSeconds(lockTime);

        Shoot(endPoint, dir);
    }

    void Shoot (Vector2 endPoint, Vector3 dir)
    {
        //Animation
        StartShoot();

        //SOund
        FindObjectOfType<Audio_Manager>().Play_("SniperShot");

        Debug.Log("Shoot");
        thickLine.enabled = true;

        aimLine.enabled = false;

        thickLine.SetPosition(0, transform.position);
        thickLine.SetPosition(1, endPoint);


        //Check if sth. is blocking the way
        RaycastHit2D hit = Physics2D.Raycast(transform.position, dir, 100, allesAu�erEenemy); //damit ich der sniper nicht selber hittet

        //Debug.Log(hit.collider.gameObject.layer);

        if (hit.collider.gameObject.layer == 7)
        {
            DamagePlayer_();
        } else if (hit.collider.gameObject.layer == 3)
        {
            DestroyShield_();
        } else if (hit.collider.gameObject.layer == 6)
        {
            //Hit the wall, do nothing
        }
        else
        {
            //eig sollte es kein else geben, aber das sit wenn weder player noch Schild gehittet wurden. 
            Debug.Log(hit.collider.gameObject.layer);
            Debug.LogError("Un problemo");
        }


        StartCoroutine(WaitForFlashTime());

    }

    IEnumerator WaitForFlashTime ()
    {
        yield return new WaitForSeconds(LaserFlashTime);

        ResetSniperBools();
    }

    void ResetSniperBools ()
    {
        StopAllCoroutines();
        StopAming();

        thickLine.enabled = false;
        aimLine.enabled = false;

        isAiming = false;
        isLocking = false;
        isChasing = false;

        isMoving = true;
        myAgent.isStopped = false;
    }

    void Rotate()
    {
        Vector2 AimDir = (transform.position - playerO.transform.position);
        Quaternion rotation = Quaternion.LookRotation(Vector3.forward, AimDir);
        transform.rotation = rotation;
    }

    void DestroyShield_ ()
    {
        BulletManager bulletManager = playerO.GetComponent<BulletManager>();

        bulletManager.DestroyShield();
        bulletManager.StartNewShieldCorutine();
    }

    void DamagePlayer_ ()
    {
        playerO.GetComponent<LivesManager>().ChangePlayerLives(-sniperDamage); 
    }

    void StartWalk()
    {       

        if (!isPlayingHitAnimation)
        {
            animator.Play("Walk");
        }
    }

    void StartAim()
    {       

        if (!isPlayingHitAnimation)
        {
            animator.Play("Aim");
        }
    }


    void StartShoot()
    {       

        if (!isPlayingHitAnimation)
        {
            animator.Play("Shoot");
        }
    }

    void StartSpawn()
    {
        animator.Play("Spawn");

    }


    public void StartHit()
    {
        isPlayingHitAnimation = true;
        animator.Play("Hit");

        StartCoroutine(waitAfterHit());
    }

    IEnumerator waitAfterHit()
    {
        yield return new WaitForSeconds(hitAnimationDuration);
        isPlayingHitAnimation = false;

        StartWalk();
    }
}
