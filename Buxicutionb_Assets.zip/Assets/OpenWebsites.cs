using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OpenWebsites : MonoBehaviour
{
    public string YT;
    public string GP;

    public void OpenYT()
    {
        Application.OpenURL(YT);
    }

    public void OpenGP()
    {
        Application.OpenURL(GP);
    }
}
