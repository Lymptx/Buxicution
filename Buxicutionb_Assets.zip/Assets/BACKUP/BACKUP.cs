using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BACKUP : MonoBehaviour
{
    //void Update_Xvel()
    //{


    //    ////       VEL +                 TAR +
    //    ////Sind VEL und TAR beide POSITIV
    //    //if (rb.velocity.x >= 0 && targetVelocity_X >= 0)
    //    //{
    //    //    //VEL kleiner als TAR --> Beschleunigung
    //    //    if (rb.velocity.x < targetVelocity.x)
    //    //    {
    //    //        targetVelocity_X = Mathf.SmoothDamp(rb.velocity.x, targetVelocity_X, ref NullFloat, StartSmooth);
    //    //    }
    //    //    //VEL gr��er als TAR --> Bremsen
    //    //    else if (rb.velocity.x > targetVelocity.x)
    //    //    {
    //    //        targetVelocity_X = Mathf.SmoothDamp(rb.velocity.x, targetVelocity_X, ref NullFloat, StopSmooth);
    //    //    }
    //    //}



    //    ////       VEL +                 TAR -
    //    ////Ist VEL POSITIV und TAR NEGATIV
    //    //else if (rb.velocity.x >= 0 && targetVelocity_X < 0)
    //    //{
    //    //    //+VEL immer gr��er als -TAR --> Bremsen
    //    //    targetVelocity_X = Mathf.SmoothDamp(rb.velocity.x, targetVelocity_X, ref NullFloat, StopSmooth);

    //    //}



    //    ////       VEL -                TAR -
    //    ////Sind VEL und TAR beide NEGATIV
    //    //else if (rb.velocity.x < 0 && targetVelocity_X < 0)
    //    //{
    //    //    //-VEL gr��er als -TAR --> Beschleunigung
    //    //    if (rb.velocity.x > targetVelocity.x)
    //    //    {
    //    //        targetVelocity_X = Mathf.SmoothDamp(rb.velocity.x, targetVelocity_X, ref NullFloat, StartSmooth);
    //    //    }
    //    //    //-VEL kleiner als -TAR --> Bremsen
    //    //    else if (rb.velocity.x < targetVelocity.x)
    //    //    {
    //    //        targetVelocity_X = Mathf.SmoothDamp(rb.velocity.x, targetVelocity_X, ref NullFloat, StopSmooth);
    //    //    }
    //    //}



    //    ////       VEL -                TAR +
    //    ////Ist VEL NEGATIV und TAR POSITIV
    //    //else if (rb.velocity.x < 0 && targetVelocity_X >= 0)
    //    //{
    //    //    //-VEL immer kleiner als +TAR
    //    //    targetVelocity_X = Mathf.SmoothDamp(rb.velocity.x, targetVelocity_X, ref NullFloat, StartSmooth);
    //    //}
    //}

    //void Update_Yvel()
    //{

    //    ////       VEL +                 TAR +
    //    ////Sind VEL und TAR beide POSITIV
    //    //if (rb.velocity.y >= 0 && targetVelocity_Y >= 0)
    //    //{
    //    //    Debug.Log("Y |VEL+ TAR+|");
    //    //    //VEL kleiner als TAR --> Beschleunigung
    //    //    if (rb.velocity.y < targetVelocity.y)
    //    //    {
    //    //        Debug.Log("Start");
    //    //        targetVelocity_Y = Mathf.SmoothDamp(rb.velocity.y, targetVelocity_Y, ref NullFloat, StartSmooth);
    //    //    }
    //    //    //VEL gr��er als TAR --> Bremsen
    //    //    else if (rb.velocity.y > targetVelocity.y)
    //    //    {
    //    //        Debug.Log("Stop");
    //    //        targetVelocity_Y = Mathf.SmoothDamp(rb.velocity.y, targetVelocity_Y, ref NullFloat, StopSmooth);
    //    //    }
    //    //}



    //    //////       VEL +                 TAR -
    //    //////Ist VEL POSITIV und TAR NEGATIV
    //    ////else if (rb.velocity.y >= 0 && targetVelocity_Y < 0)
    //    ////{
    //    ////    //+VEL immer gr��er als -TAR --> Bremsen
    //    ////    targetVelocity_Y = Mathf.SmoothDamp(rb.velocity.y, targetVelocity_Y, ref NullFloat, StopSmooth);

    //    ////}



    //    ////       VEL -                TAR -
    //    ////Sind VEL und TAR beide NEGATIV
    //    //else if (rb.velocity.y < 0 && targetVelocity_Y < 0)
    //    //{
    //    //    Debug.Log("Y |VEL- TAR-|");
    //    //    //-VEL gr��er als -TAR --> Beschleunigung
    //    //    if (rb.velocity.y > targetVelocity.y)
    //    //    {
    //    //        Debug.Log("Start");
    //    //        targetVelocity_Y = Mathf.SmoothDamp(rb.velocity.y, targetVelocity_Y, ref NullFloat, StartSmooth);
    //    //    }
    //    //    //-VEL kleiner als -TAR --> Bremsen
    //    //    else if (rb.velocity.y < targetVelocity.y)
    //    //    {
    //    //        Debug.Log(rb.velocity.y);
    //    //        targetVelocity_Y = Mathf.SmoothDamp(rb.velocity.y, targetVelocity_Y, ref NullFloat, StopSmooth);
    //    //    }
    //    //}



    //    //////       VEL -                TAR +
    //    //////Ist VEL NEGATIV und TAR POSITIV
    //    ////else if (rb.velocity.y < 0 && targetVelocity_Y >= 0)
    //    ////{
    //    ////    //-VEL immer kleiner als +TAR
    //    ////    targetVelocity_Y = Mathf.SmoothDamp(rb.velocity.y, targetVelocity_Y, ref NullFloat, StartSmooth);
    //    ////}
    //}

    //public Rigidbody2D rb;

    //public float maxSpeed = 20f;
    //public float acceleration = 5f;
    //public float wait_before_stop = 1f;

    //Vector2 targetVelocity;
    //Vector2 Velocity;

    //private float Stepsize;

    //private void Start()
    //{
    //    Stepsize = wait_before_stop * 50;
    //}

    //private void Update()
    //{
    //    targetVelocity.x = Input.GetAxisRaw("Horizontal") * acceleration;
    //    targetVelocity.y = Input.GetAxisRaw("Vertical") * acceleration;
    //    Stepsize = wait_before_stop * 50;
    //}

    //void FixedUpdate()
    //{
    //    rb.velocity += targetVelocity * Time.fixedDeltaTime;
    //    Velocity = rb.velocity;
    //    Friction();
    //}

    //void Friction()
    //{
    //    if (Velocity.x > 0)
    //    {
    //        Velocity.x = Slow_Down_float(Velocity.x);
    //    }
    //    if (Velocity.y > 0)
    //    {
    //        Velocity.y = Slow_Down_float(Velocity.y);
    //    }

    //    rb.velocity = new Vector2(Velocity.x, Velocity.y);
    //}

    //float Slow_Down_float(float x)
    //{
    //    x -= x / Stepsize;
    //    return x;
    //}
}
