using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerBullet : MonoBehaviour
{
    public float damage;

    private void OnTriggerEnter2D(Collider2D collision)
    {
        //Wand
        if (collision.gameObject.layer == 6)
        {
            Destroy(gameObject);
        }
        //Enemy Bullet
        else if (collision.gameObject.layer == 9)
        {
            Destroy(collision.gameObject);
        } else if (collision.gameObject.layer == 11)
        {
            //Boss
            collision.gameObject.GetComponent<BossLives>().DamageBoss();
            Destroy(gameObject);
        }
        //Enemy
        else if (collision.gameObject.layer == 10)
        {
            //mti einem enemy colided
            Destroy(gameObject, 0.1f); //diese bullet zerst�ren
            EnemyLives enemyLives = collision.gameObject.GetComponent<EnemyLives>();

            if(collision.gameObject.tag != "BombBug")
            {
                //Bei normalen enemies zerst�ren
                enemyLives.DamageEnemy(damage);
            }
            

            //falls bombe
            if(collision.gameObject.tag == "BombBug")
            {
                //if(enemyLives.myLives - damage <= 0)/-----------------dieses system wurde am 26.11.2021 ge�ndert
                //{
                //    //Schauen ob die Bombe sterben w�rde, wenn man ihr jetzt Schaden hinzuf�gt. Falls ja:
                //    collision.gameObject.GetComponent<EnemyAiMovement>().StartEnemySelfBlowUp();
                //    Debug.Log("Self blow up");
                //} else
                //{
                //    //Falls nicht, normal einfach Schaden machen
                //    enemyLives.DamageEnemy(damage);
                //    Debug.Log("normal damage");
                //}

                enemyLives.DamageEnemy(damage);


            }
        }
    }
}
