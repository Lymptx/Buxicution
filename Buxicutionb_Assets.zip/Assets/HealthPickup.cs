using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HealthPickup : MonoBehaviour
{

    public float pickupHealthRegeneration;

    public float simpleHealthRegeneration;
    public float normalHealthRegeneration;
    public float nightmareHealthRegeneration;



    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.layer == 7)
        {
            //The player is collecting this pickup

            //Give the player lives
            FindObjectOfType<LivesManager>().ChangePlayerLives(pickupHealthRegeneration);

            //make some kind of soud
            FindObjectOfType<Audio_Manager>().Play_("PickupSound");

            //Destroy this pickup
            Destroy(gameObject);


        }

    }

    


    private void Update()
    {
        if (PlayerPrefs.GetInt("Difficulty") == 1)
        {
            pickupHealthRegeneration = simpleHealthRegeneration;


        } else if (PlayerPrefs.GetInt("Difficulty") == 2)
        {
            pickupHealthRegeneration = normalHealthRegeneration;


        } else if (PlayerPrefs.GetInt("Difficulty") == 3)
        {
            pickupHealthRegeneration = nightmareHealthRegeneration;
        }
    }



}
