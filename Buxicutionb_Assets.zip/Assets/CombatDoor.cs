using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CombatDoor : MonoBehaviour
{
    public DoorOpening doorOpeningScript;

    public void OpenDoor()
    {
        doorOpeningScript.ChangeDoorState(true);
    }

    public void CloseDoor ()
    {
        doorOpeningScript.ChangeDoorState(false);

    }
}
