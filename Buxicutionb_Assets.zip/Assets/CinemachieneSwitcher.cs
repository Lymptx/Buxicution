using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Cinemachine;

public class CinemachieneSwitcher : MonoBehaviour
{

    public bool isMainCam;

    public CinemachineVirtualCamera mainCam; //main 

    public CinemachineVirtualCamera T�r1Cam; //combat raum 1
    public CinemachineVirtualCamera T�r2Cam;
    public CinemachineVirtualCamera T�r3Cam;
    public CinemachineVirtualCamera Full1Cam;
    public CinemachineVirtualCamera Full2Cam;
    public CinemachineVirtualCamera Full3Cam;

    public void SwitchToMainCan()
    {
        AllCamsToZero();
        mainCam.Priority = 1;
    }

    public void ZoomToCam(bool isDoorCam, int Index) //true ist t�r
    {      
        AllCamsToZero();

        //create the string
        string camType_;

        if (isDoorCam)
        {
            camType_ = "T�r";
        } else
        {
            camType_ = "Full";
        }

        string camName = (camType_ + Index + "Cam").ToString();

        if (T�r1Cam.gameObject.transform.name == camName)
        {
            T�r1Cam.Priority = 1;
        }

        if (T�r2Cam.gameObject.transform.name == camName)
        {
            T�r2Cam.Priority = 1;
        }

        if (T�r3Cam.gameObject.transform.name == camName)
        {
            T�r3Cam.Priority = 1;
        }

        if (Full1Cam.gameObject.transform.name == camName)
        {
            Full1Cam.Priority = 1;
        }

        if (Full2Cam.gameObject.transform.name == camName)
        {
            Full2Cam.Priority = 1;
        }

        if (Full3Cam.gameObject.transform.name == camName)
        {
            Full3Cam.Priority = 1;
        }


    }


    void AllCamsToZero ()
    {
        //Keine von diesen Cameras soll rendern
        mainCam.Priority = 0;

        T�r1Cam.Priority = 0;
        T�r2Cam.Priority = 0;
        Full1Cam.Priority = 0;
        Full2Cam.Priority = 0;
    }
}
