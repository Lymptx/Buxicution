using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerShoot : MonoBehaviour
{
    public Rigidbody2D rb;
    public LayerMask BulletLayer;
    float PewPewSpeed;
    Player_Movement player_Movement;
    BulletManager bulletManager;

    //bool issHot = false;

    private void Start()
    {
        player_Movement = gameObject.transform.parent.gameObject.GetComponent<Player_Movement>();
        bulletManager = gameObject.transform.parent.gameObject.GetComponent<BulletManager>();
        PewPewSpeed = bulletManager.PewPewSpeed;
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Mouse0))
        {
               
        }
    }


    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.collider.gameObject.layer == BulletLayer)
        {
            Destroy_PewPew_Time(0);
        }       
    }

    public void Destroy_PewPew_Time(float time)
    {
        Destroy(gameObject, time);
        //issHot = false;     
    }
}
