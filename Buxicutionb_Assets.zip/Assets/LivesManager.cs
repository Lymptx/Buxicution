using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class LivesManager : MonoBehaviour
{
    public float healthRegenerationAmount;

    public float simplehealthRegenerationAmount;
    public float normalhealthRegenerationAmount;
    public float nightmarehealthRegenerationAmount;

    public float simpledamageFromTurretBullet;
    public float normaldamageFromTurretBullet;
    public float nightmaredamageFromTurretBullet;


    public Text livesCounter;
    public float startLives;
    public float currentLives;


    public float lives_before = 1f;
    public float lives_after = 1f;


    [Header("Lives and Damage")]
    public float damageFromTurretBullet;

    public BulletManager bulletManager;

    public bool selfdemage = false;

    private void Start()
    {
        currentLives = startLives;
    }

    public void PlayerToFullLives()
    {
        currentLives = startLives;
    }

    public void ChangePlayerLives(float changeAmount)
    {

        if (changeAmount < 0 && selfdemage == false)
        {
            //Player gets damaged not healed
            FindObjectOfType<Audio_Manager>().Play_("PlayerDamage");
        }
        lives_before = currentLives / startLives;
        currentLives += changeAmount;

        if(currentLives > startLives)
        {
            currentLives = startLives;
        }

        lives_after = currentLives / startLives;

        if (currentLives == 100)
        {
            livesCounter.text = currentLives.ToString("F0");
        }
        else
        {
            livesCounter.text = currentLives.ToString("F1");
        }  

        if (currentLives <= 0)
        {
            FindObjectOfType<DiedMenu>().PlayerDied();
        }

         
    }



    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.collider.gameObject.layer == 9)
        {
            //Got hit by a turret bullet

            //Destroy the bullet
            Destroy(collision.gameObject);

            //Remove Lives
            ChangePlayerLives(-damageFromTurretBullet);



        }
    }


    private void Update()
    {
        ChangePlayerLives(Time.deltaTime * healthRegenerationAmount);


        if (PlayerPrefs.GetInt("Difficulty") == 1)
        {
            healthRegenerationAmount = simplehealthRegenerationAmount;
            damageFromTurretBullet = simpledamageFromTurretBullet;


        }
        else if (PlayerPrefs.GetInt("Difficulty") == 2)
        {
            healthRegenerationAmount = normalhealthRegenerationAmount;
            damageFromTurretBullet = normaldamageFromTurretBullet;


        }
        else if (PlayerPrefs.GetInt("Difficulty") == 3)
        {
            healthRegenerationAmount = nightmarehealthRegenerationAmount;
            damageFromTurretBullet = nightmaredamageFromTurretBullet;
        }
    }
}
