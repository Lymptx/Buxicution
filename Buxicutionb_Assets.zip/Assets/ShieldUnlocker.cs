using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShieldUnlocker : MonoBehaviour
{

    public float LerpTime;
    bool isLerping;

    public Transform unlockPos;
    Vector3 lerpStartPos;
    public GameObject player;
    public BulletManager bulletManager;
    public CombatRaumManager combatRaumManager;

    public float WaitBeforeShieldUnlock;
    public float WaitAfterShieldUnlock;

    bool hasAlreadyLerped;

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if(!hasAlreadyLerped)
        {
            if (collision.gameObject.layer == 7)
            {
                //collided with player
                lerpStartPos = player.transform.position;
                LerpToPos();

            }
        }


    }

    void LerpToPos ()
    {
        player.GetComponent<Player_Movement>().SetPlayerControl(false);
        isLerping = true;

    }


    private void Update()
    {
        if (isLerping)
        {
            if(player != null)
            {
                player.transform.position = Vector2.Lerp(player.transform.position, unlockPos.position, Time.deltaTime * LerpTime);

                player.GetComponent<Player_Movement>().SetPlayerControl(false);
                Debug.Log("lerping");
            }
            
        }

        if(!hasAlreadyLerped)
        {
            if(player != null)
            {
                if (Vector2.Distance(player.transform.position, unlockPos.position) < 0.2f)
                {
                    //Finished Lerping
                    if (!hasAlreadyLerped)
                    {
                        StartCoroutine(FinishedLerping());
                        Debug.Log("WUT");
                    }

                    //StartCoroutine(FinishedLerping());


                }
            }
            
        }

        

    }


    IEnumerator FinishedLerping()
    {
        yield return new WaitForSeconds(WaitBeforeShieldUnlock);

        //Unlock Shield
        bulletManager.ActivateShieldInFirstLevel();

        yield return new WaitForSeconds(WaitAfterShieldUnlock);

        
        if(player != null)
        {
            //Resume
            player.GetComponent<Player_Movement>().SetPlayerControl(true);
            hasAlreadyLerped = true;
            isLerping = false;
            combatRaumManager.AllEnemiesDead(); //damit der doortrigger aktiviert wird und die Kamera zur T�r zoomt. 

            player = null; //klebebandfix
        }
        
    }

}
