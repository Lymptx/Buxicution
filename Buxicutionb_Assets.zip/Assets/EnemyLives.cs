using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyLives : MonoBehaviour
{

    [Header("My lives")]
    public float myLives;

    public bool isTurret;
    public bool isBomb;

    CombatRaumManager combatRaumManager;

    [Header("Scripts")]
    public EnemyAiMovement bombScript;
    public Static_Turret_Enemy turretScript;
    public SniperEnemy sniperScript;

    bool alreadyDead = false; //Nur damit der bombcounter nicht ins minus geht, wenn ich diese funktion doch unabsichtlich yweimal aufrufe

    void Start ()
    {
        //if(isBomb)
        //{
        //    bombScript = gameObject.GetComponent<EnemyAiMovement>();
        //}
        //else if (isTurret)
        //{
        //    turretScript = gameObject.GetComponent<Static_Turret_Enemy>();

        //}
        //else if (!isTurret && !isBomb)
        //{
        //    //Is the sinper
        //    sniperScript = gameObject.GetComponent<SniperEnemy>();
        //}
    }

    public void DamageEnemy (float damage)
    {
        myLives -= damage; //beides public floats, die wir dann im inspektor setzten

        //PlayHItAnimations
        if (isBomb)
        {
            bombScript.StartHit();

        }
        else if (isTurret)
        {
            turretScript.StartHit();

        }
        else if (!isTurret && !isBomb)
        {
            //Is the sinper
            sniperScript.StartHit();
        }



        if (myLives <= 0)
        {




            //Die
            if (isBomb)
            {
                //Change the bomb counter if a bomb dies
                if(!alreadyDead)
                {
                    FindObjectOfType<CombatRaumManager>().BombDied();
                    alreadyDead = true;
                }

                bombScript.StartEnemySelfBlowUp();




            } else if (isTurret)
            {
                //bissi hangeln zum Hauptparent wenn es turret ist
                FindObjectOfType<CombatRaumManager>().EnemyDied();

                //Spawn a pickup
                FindObjectOfType<PickupSpawner>().SpawnPickup(transform.position);

                Destroy(gameObject.transform.parent.gameObject.transform.parent.gameObject);




            } else if (!isTurret && !isBomb)
            {
                //Is the sinper

                //dead count
                FindObjectOfType<CombatRaumManager>().EnemyDied();

                //Spawn a pickup
                FindObjectOfType<PickupSpawner>().SpawnPickup(transform.position);

                Destroy(gameObject);
            }
            
        }
    }
}
