using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class turretBullet : MonoBehaviour
{
    public BulletManager bulletManager;
    public LivesManager livesManager;

    public int damageFromTurretBullet;

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.collider.gameObject.layer == 3)
        {
            //hit the player
            ////Destroy the Shield of the player
            bulletManager.DestroyShield();
            bulletManager.StartNewShieldCorutine();

            
        } //else if (collision.collider.gameObject.layer == 7)
        //{
        //    //call some take damage on the player
        //    livesManager.ChangePlayerLives(-damageFromTurretBullet);

        //    Debug.Log("Error");

        //}

        Destroy(gameObject);

    }
}
