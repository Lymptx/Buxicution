using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DoorOpening : MonoBehaviour
{
    private Vector2 startPos;
    private Vector2 openPos;
    private Vector2 newPosition;

    public Transform HidePos;

    public float OpenTime = 3;

    bool doorState;



    private void Awake()
    {
        startPos = transform.position;
        openPos = HidePos.position;

    }


    public void ChangeDoorState(bool newState) //true should open, false should close
    {
        doorState = newState;
    }

    private void Update()
    {
        if (!doorState)
        {
            newPosition = startPos;
        }
        else
        {
            newPosition = openPos;
        }

        transform.position = Vector2.Lerp(transform.position, newPosition, Time.deltaTime * OpenTime);
    }
}
