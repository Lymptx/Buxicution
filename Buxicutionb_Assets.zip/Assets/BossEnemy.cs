using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BossEnemy : MonoBehaviour
{
    [Header("General")]
    public GameObject Player;
    public BulletManager bulletManager;
    public LivesManager livesManager;
    public CombatRaumManager combatRaumManager;


    [Header("Phases")]
    public bool isFirstPhase;
    public bool isSecondPhase;
    public bool isThirdPhase;

    /// <summary>
    /// 1 Phase: Einfach turret, nur in 4 rictungen
    /// 2 Phase: zwei sniper sch�sse aus beiden augen kommen dazu
    /// 3 Phase: Er beginnt auch Bomben zu spawnen. 
    /// </summary>



    [Header("Phase 1")]
    public GameObject bulletPrefab;
    public float bulletSpeed;
    public Transform SpawnPos1;
    public Transform SpawnPos2;
    public Transform SpawnPos3;
    public Transform SpawnPos4;

    //Cooldown
    public float shootCooldown;
    float currentCooldown;


    [Header("Phase 2")]
    public float sniperDamage;
    public LayerMask groundLayer;
    public LayerMask allesAusserGround;
    public LayerMask allesAu�erEenemy;
    public bool isAiming;
    public bool PlayerInSight;
    public bool isLocking; //Der Sstate, wo nach einer Zeit der Strahl einf an der Stelle bleibt
    public bool isLocking2;
    public bool isChasing; //Der State, wo er stehenbleibt und den Player mit dem d�nnen Strahl verfolgt
    public float verfolgTime; //Die zwei Sec, wo er den player verfolgt
    public float lockTime; // locks onto the position
    public LineRenderer aim1Line;
    public LineRenderer thick1Line;
    public LineRenderer aim2Line;
    public LineRenderer thick2Line;
    public float LaserFlashTime;
    private Transform lastPlayerPos; 
    public Transform Auge1; //Die laser werden aus verschiedenen Augen kommen. 
    public Transform Auge2;

    [Header("Phase 3")]
    public BossBombs bossBombs;






    private void Start()
    {
        isFirstPhase = true;
    }

    public void StartSecondPhase ()
    {
        isSecondPhase = true;
    }

    public void StartThirdPhase()
    {
        isThirdPhase = true;
    }



    private void Update()
    {

        //Shoot
        if (isFirstPhase)
        {
            if (currentCooldown < 0)
            {
                //Shoot
                ShootBullets();
                currentCooldown = shootCooldown;

            }
            else
            {
                currentCooldown -= Time.deltaTime;
            }
        }


        if (isSecondPhase)
        {
            //Check is player is in sight
            if (Physics2D.Linecast(gameObject.transform.position, Player.transform.position, groundLayer))
            {
                //is there is a collier between the player and this enemy. (or the excapt opposite, see later with debugging)
                PlayerInSight = false;

                if (isChasing && !isLocking && !isLocking2)
                {
                    ResetSniperBools();
                }

            }

            if (!Physics2D.Linecast(gameObject.transform.position, Player.transform.position, groundLayer))
            {
                //is there is a collier between the player and this enemy. (or the excapt opposite, see later with debugging)
                PlayerInSight = true;
            }

            //Start Aming
            if (PlayerInSight) //also check later if the player is in sight
            {
                if (!isLocking && !isLocking2)
                {
                    StartAming();
                }
            }
        }

        if (isThirdPhase)
        {
            if (!bossBombs.isSpawning)
            {
                //The first time it got into this loop
                bossBombs.isSpawning = true;
                bossBombs.SpawnNewBomb();
            }
        }

    }



    void ShootBullets()
    {
        GameObject bullet1 = Instantiate(bulletPrefab, SpawnPos1.position, Quaternion.identity);
        GameObject bullet2 = Instantiate(bulletPrefab, SpawnPos2.position, Quaternion.identity);
        GameObject bullet3 = Instantiate(bulletPrefab, SpawnPos3.position, Quaternion.identity);
        GameObject bullet4 = Instantiate(bulletPrefab, SpawnPos4.position, Quaternion.identity);

        turretBullet bulletScript1 = bullet1.GetComponent<turretBullet>();
        turretBullet bulletScript2 = bullet2.GetComponent<turretBullet>();
        turretBullet bulletScript3 = bullet3.GetComponent<turretBullet>();
        turretBullet bulletScript4 = bullet4.GetComponent<turretBullet>();

        bulletScript1.bulletManager = bulletManager;
        bulletScript2.bulletManager = bulletManager;
        bulletScript3.bulletManager = bulletManager;
        bulletScript4.bulletManager = bulletManager;

        bulletScript1.livesManager = livesManager;
        bulletScript2.livesManager = livesManager;
        bulletScript3.livesManager = livesManager;
        bulletScript4.livesManager = livesManager;

        Rigidbody2D rb1 = bullet1.GetComponent<Rigidbody2D>();
        Rigidbody2D rb2 = bullet2.GetComponent<Rigidbody2D>();
        Rigidbody2D rb3 = bullet3.GetComponent<Rigidbody2D>();
        Rigidbody2D rb4 = bullet4.GetComponent<Rigidbody2D>();

        Vector2 dir1 = new Vector2(0, 0);
        Vector2 dir2 = new Vector2(0, 0);
        Vector2 dir3 = new Vector2(0, 0);
        Vector2 dir4 = new Vector2(0, 0);

        dir1 = (SpawnPos1.position - gameObject.transform.position);
        dir2 = (SpawnPos2.position - gameObject.transform.position);
        dir3 = (SpawnPos3.position - gameObject.transform.position);
        dir4 = (SpawnPos4.position - gameObject.transform.position);

        rb1.AddForce(dir1.normalized * bulletSpeed);
        rb2.AddForce(dir2.normalized * bulletSpeed);
        rb3.AddForce(dir3.normalized * bulletSpeed);
        rb4.AddForce(dir4.normalized * bulletSpeed);

    }


    void StopAming()
    {
        aim1Line.enabled = false;
        aim2Line.enabled = false;

        isAiming = false;
    }


    void StartAming()
    {
        aim1Line.enabled = true;
        aim2Line.enabled = true;

        isAiming = true;


        lastPlayerPos = Player.transform;
        //Line 
        DrawD�nneLinie();

        if (!isChasing)
        {
            StartCoroutine(StartSipingCountdown());
        }
    }


    void DrawD�nneLinie() //Ich h'tte auch gleich 2 Funktionen machen k�nnen
    {
        //Set the linerenderer

        Vector3 dir = new Vector3();
        dir = (lastPlayerPos.position - Auge1.position).normalized;

        //Line 1
        dir = (lastPlayerPos.position - Auge1.position).normalized;
        Vector3 wall1Point;
        RaycastHit2D hit = Physics2D.Raycast(Auge1.position, dir, 100, groundLayer);
        wall1Point = hit.point;
        aim1Line.SetPosition(0, Auge1.position);
        aim1Line.SetPosition(1, wall1Point);

        //Line 2
        dir = (lastPlayerPos.position - Auge2.position).normalized;
        Vector3 wall1Point_;
        RaycastHit2D hit_ = Physics2D.Raycast(Auge2.position, dir, 100, groundLayer);
        wall1Point_ = hit_.point;
        aim2Line.SetPosition(0, Auge2.position);
        aim2Line.SetPosition(1, wall1Point_);


        //// If it hits something...
        //if (hit.collider != null)
        //{
        //    //hit te wall

        //}
        //else
        //{
        //    Debug.LogError(" CANNOT HIT WALL");
        //}


    }

    IEnumerator StartSipingCountdown()
    {
        isChasing = true;

        yield return new WaitForSeconds(verfolgTime);

        isAiming = false;

        Start1Lock();
        Start2Lock();
    }

    void Start1Lock()
    {
        isAiming = false;

        ///do some raycast work
        Vector2 lockPointEnd;

        Vector3 dir = new Vector3();
        dir = (lastPlayerPos.position - Auge1.position).normalized;

        RaycastHit2D hit = Physics2D.Raycast(Auge1.position, dir, 100, groundLayer);

        //textPoint.transform.position = hit.point;
        lockPointEnd = hit.point;

        lastPlayerPos = Player.transform;
        //raycast end----------

        aim1Line.SetPosition(1, lockPointEnd);

        if (!isLocking)
        {
            StartCoroutine(Start1LockTime(lockPointEnd, dir));
        }

        isLocking = true;
    }

    void Start2Lock()
    {
        isAiming = false;

        ///do some raycast work
        Vector2 lockPointEnd;

        Vector3 dir = new Vector3();
        dir = (lastPlayerPos.position - Auge2.position).normalized;

        RaycastHit2D hit = Physics2D.Raycast(Auge2.position, dir, 100, groundLayer);

        //textPoint.transform.position = hit.point;
        lockPointEnd = hit.point;

        lastPlayerPos = Player.transform;
        //raycast end----------

        aim2Line.SetPosition(1, lockPointEnd);

        if (!isLocking2)
        {
            StartCoroutine(Start2LockTime(lockPointEnd, dir));
        }

        isLocking2 = true;
    }

    IEnumerator Start1LockTime(Vector2 endPoint, Vector3 dir)
    {
        //isLocking = true;

        yield return new WaitForSeconds(lockTime);

        Shoot1Sniper(endPoint, dir);
    }

    IEnumerator Start2LockTime(Vector2 endPoint, Vector3 dir)
    {
        //isLocking = true;

        yield return new WaitForSeconds(lockTime);

        Shoot2Sniper(endPoint, dir);
    }

    void Shoot1Sniper(Vector2 endPoint, Vector3 dir)
    {
        //SOund
        FindObjectOfType<Audio_Manager>().Play_("SniperShot");

        thick1Line.enabled = true;

        aim1Line.enabled = false;

        thick1Line.SetPosition(0, Auge1.position);
        thick1Line.SetPosition(1, endPoint);


        //Check if sth. is blocking the way
        RaycastHit2D hit = Physics2D.Raycast(Auge1.position, dir, 100, allesAu�erEenemy); //damit ich der sniper nicht selber hittet

        //Debug.Log(hit.collider.gameObject.layer);

        if (hit.collider.gameObject.layer == 7)
        {
            DamagePlayer_();
        }
        else if (hit.collider.gameObject.layer == 3)
        {
            DestroyShield_();
        }
        else if (hit.collider.gameObject.layer == 6)
        {
            //Hit the wall, do nothing
        }
        else
        {
            //eig sollte es kein else geben, aber das sit wenn weder player noch Schild gehittet wurden. 
            Debug.Log(hit.collider.gameObject.layer);
            Debug.LogError("Un problemo");
        }


        StartCoroutine(WaitForFlashTime());

    }

    void Shoot2Sniper(Vector2 endPoint, Vector3 dir)
    {
        //SOund
        FindObjectOfType<Audio_Manager>().Play_("SniperShot");

        Debug.Log("Shoot_");
        thick2Line.enabled = true;

        aim2Line.enabled = false;

        thick2Line.SetPosition(0, Auge2.position);
        thick2Line.SetPosition(1, endPoint);


        //Check if sth. is blocking the way
        RaycastHit2D hit = Physics2D.Raycast(Auge2.position, dir, 100, allesAu�erEenemy); //damit ich der sniper nicht selber hittet

        //Debug.Log(hit.collider.gameObject.layer);

        if (hit.collider.gameObject.layer == 7)
        {
            DamagePlayer_();
        }
        else if (hit.collider.gameObject.layer == 3)
        {
            DestroyShield_();
        }
        else if (hit.collider.gameObject.layer == 6)
        {
            //Hit the wall, do nothing
        }
        else
        {
            //eig sollte es kein else geben, aber das sit wenn weder player noch Schild gehittet wurden. 
            Debug.Log(hit.collider.gameObject.layer);
            Debug.LogError("Un problemo");
        }


        StartCoroutine(WaitForFlashTime());

    }

    IEnumerator WaitForFlashTime()
    {
        yield return new WaitForSeconds(LaserFlashTime);

        ResetSniperBools();
    }

    void ResetSniperBools()
    {
        //StopAllCoroutines();
        StopAming();

        thick1Line.enabled = false;
        aim1Line.enabled = false;
        thick2Line.enabled = false;
        aim2Line.enabled = false;

        isAiming = false;
        isLocking = false;
        isLocking2 = false;
        isChasing = false;

    }


    void DestroyShield_()
    {
        BulletManager bulletManager = Player.GetComponent<BulletManager>();

        bulletManager.DestroyShield();
        bulletManager.StartNewShieldCorutine();
    }

    void DamagePlayer_()
    {
        Player.GetComponent<LivesManager>().ChangePlayerLives(-sniperDamage);
    }


}
