using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BossRotator : MonoBehaviour
{
    public GameObject Player;

    private void Update()
    {
        Rotate();
    }

    void Rotate()
    {
        Vector2 AimDir = (transform.position - Player.transform.position);
        Quaternion rotation = Quaternion.LookRotation(Vector3.forward, AimDir);
        transform.rotation = rotation;
    }

}
