using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CombatRaumManager : MonoBehaviour
{
    public Player_Movement playerMovement;
    public bool isBossFight;
    public GameObject BossHealthbar;
    LivesManager livesManager;

    public int currentRoomIndex;


    public GameObject[] DoorOpenTriggers; //Das ist ein Array aus triggern, vielleiht auch sp�ter von der ganzen t�r
    public DoorOpening[] doorOpeningScripts;

    public GameObject PlayerUI;



    //[System.Serializable]
    //public class TrackEnemies
    //{
    //    public GameObject enemy;
    //    public bool dead;
    //}
    
    public GameObject[] EnemiesRoom1;
    public GameObject[] EnemiesRoom2;
    public GameObject[] EnemiesRoom3;
    public int enemyCounter;
    public int bombCounter;

    public CinemachieneSwitcher camManager;
    public int camZoomTime;
    public int enemySpawnWaitTime;

    public float waitTimeAfterEnemyDeath;

    private void Start()
    {
        livesManager = playerMovement.gameObject.GetComponent<LivesManager>();
    }

    /// <summary>
    /// Keeping track of enemies
    /// </summary>\
    /// 
    public void SpawnEnemies(int RoomIndex)
    {
        //Set enemis active according to the room

        if (RoomIndex == 1)
        {
            for (int i = 0; i < EnemiesRoom1.Length; i++)
            {
                EnemiesRoom1[i].SetActive(true);
            }
        }

        if (RoomIndex == 2)
        {
            for (int i = 0; i < EnemiesRoom2.Length; i++)
            {
                EnemiesRoom2[i].SetActive(true);
            }
        }


        if (RoomIndex == 3)
        {
            for (int i = 0; i < EnemiesRoom3.Length; i++)
            {
                EnemiesRoom3[i].SetActive(true);
            }
        }
    }

    void ResetEnemyCounter()
    {
        enemyCounter = 0;
        bombCounter = 0;
    }

    public void EnemyDied()
    {
        enemyCounter--;

        if (enemyCounter == 0 && bombCounter == 0)
        {
            //All enemies dead
            AllEnemiesDead();
        }

        if (enemyCounter <= 0)
        {
            //Stop Spawning the bombs
            StopBombSpawners();
        }
    }

    public void EnemySpawned()
    {
        enemyCounter++;
    }


    public void BombDied()
    {
        bombCounter--;

        if (enemyCounter == 0 && bombCounter == 0)
        {
            //All enemies dead
            AllEnemiesDead();
        }
    }

    public void BombSpawned()
    {
        bombCounter++;
    }







    //Exiting the Room-------------------------------------
    public void AllEnemiesDead ()
    {
        //Activate the doorTrigger to make it possible to open the door at the end of the stage
        DoorOpenTriggers[currentRoomIndex - 1].SetActive(true);

        //Stop all the bomb spawners
        StopBombSpawners();

        StartCoroutine(WaitForCameraZoomINAfterCleared());
    }


    IEnumerator WaitForCameraZoomINAfterCleared()
    {
        yield return new WaitForSeconds(waitTimeAfterEnemyDeath);

        StartCoroutine(CameraZoomingAfterEnemiesCleared());
    }


    IEnumerator CameraZoomingAfterEnemiesCleared()
    {
        //Sound abspielen
        FindObjectOfType<Audio_Manager>().Play_("RoomFinished");

        //Pause the Game
        PauseGame();

        camManager.ZoomToCam(true, currentRoomIndex);

        //HealthBar ausblenden und iwder auff[llen
        PlayerUI.SetActive(false);
        livesManager.PlayerToFullLives();

        yield return new WaitForSeconds(camZoomTime);

        //Door Animation
        doorOpeningScripts[currentRoomIndex - 1].ChangeDoorState(true); //Opens the END door

        //Wait To show Enemy Spawn Animation or the door openeing animation
        yield return new WaitForSeconds(enemySpawnWaitTime);

        //Zoom back to Player Main Cam
        camManager.SwitchToMainCan();

        //Resume the game;
        ResumeGame();

    }









    //Entering the room-------------------------------------
    public void EnteredCombatRoom (int newRoomIndex)
    {
        currentRoomIndex = newRoomIndex;

        StartCoroutine(CameraZoomingAfterEnteringRoom());

    }

    IEnumerator CameraZoomingAfterEnteringRoom ()
    {
        //Pause the Game
        PauseGame();

        //play the spawn sound
        FindObjectOfType<Audio_Manager>().Play_("EnemySpawnSound");


        //Zoom to show full room
        camManager.ZoomToCam(false, currentRoomIndex);
        PlayerUI.SetActive(false);

        yield return new WaitForSeconds(camZoomTime);

        //Spawn Enemies
        SpawnEnemies(currentRoomIndex);

        //Wait To show Enemy Spawn Animation
        yield return new WaitForSeconds(enemySpawnWaitTime);

        if (isBossFight)
        {
            //DIe Healthbar vom Boss aktivieren. 
            BossHealthbar.SetActive(true);
        }

        //Zoom back to Player Main Cam
        camManager.SwitchToMainCan();

        //Resume the game;
        ResumeGame();

        PlayerUI.SetActive(true);

    }


    void PauseGame()
    {
        //Player und enemies pausieren, ohne timescale auf 0 uyu setzen
        playerMovement.SetPlayerControl(false);
        
    }


    void ResumeGame()
    {
        //Player und enemies weitermachen
        playerMovement.SetPlayerControl(true);
        

    }



    void StopBombSpawners ()
    {
        Bombspawner[] bombSpawners = FindObjectsOfType<Bombspawner>();

        for (int i = 0; i < bombSpawners.Length; i++)
        {
            bombSpawners[i].StopSpawning();
        }

    }

}
