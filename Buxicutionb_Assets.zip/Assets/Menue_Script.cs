using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine;

public class Menue_Script : MonoBehaviour
{
    public GameObject LVPanel;
    public GameObject SettingsPanel;
    public GameObject CreditsPanel;

    private void Start()
    {
        if (PlayerPrefs.GetInt("CompletedGame") == 1)
        {
            OpenCredits();
            PlayerPrefs.SetInt("CompletedGame", 0);
        }



        if (!PlayerPrefs.HasKey("DifficultySet"))
        {
            Debug.Log("yum 1. mal");

            //Player spielt yum 1. mal
            PlayerPrefs.SetInt("DifficultySet", 1);
            PlayerPrefs.SetInt("Difficulty", 2);

        }
    }

    public void CloseAllPanels()
    {
        CloseCredits();
        CloseLVSelect();
        CloseSettings();
    }

    public void OpenLVSelect()
    {
        FindObjectOfType<Audio_Manager>().Play_("ButtonPress");
        LVPanel.SetActive(true);
    }

    public void CloseLVSelect()
    {
        FindObjectOfType<Audio_Manager>().Play_("ButtonPress");
        LVPanel.SetActive(false);
    }

    public void OpenSettings()
    {
        FindObjectOfType<Audio_Manager>().Play_("ButtonPress");
        SettingsPanel.SetActive(true);
    }

    public void CloseSettings()
    {
        FindObjectOfType<Audio_Manager>().Play_("ButtonPress");
        SettingsPanel.SetActive(false);
    }

    public void OpenCredits()
    {
        FindObjectOfType<Audio_Manager>().Play_("ButtonPress");
        CreditsPanel.SetActive(true);
    }

    public void CloseCredits()
    {
        FindObjectOfType<Audio_Manager>().Play_("ButtonPress");
        CreditsPanel.SetActive(false);
    }
}
