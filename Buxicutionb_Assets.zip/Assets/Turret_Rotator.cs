using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Turret_Rotator : MonoBehaviour
{
    public float speedRotate;

    // Start is called before the first frame update
    void Update()
    {
        transform.Rotate(Vector3.forward * speedRotate * Time.deltaTime);
    }
}
