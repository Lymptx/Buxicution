using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BossLives : MonoBehaviour
{
    public BossEnemy BossO;
    public CombatRaumManager combatManager;
    public GameObject bossEndTrigger;

    public float firstPhaseLives;
    public float secondPhaseLives;
    public float ThirdPhaseLives;

    public float totalLives;

    public void DamageBoss()
    {   
        totalLives--;

        CheckForNewPhase();
    }

    void CheckForNewPhase ()
    {
        if (totalLives < 20)
        {
            BossO.StartSecondPhase();
        }

        if (totalLives < 10)
        {
            BossO.StartThirdPhase();
        }

        if (totalLives <= 0)
        {
            //Boss FIght is aus
            bossEndTrigger.SetActive(true);
            combatManager.AllEnemiesDead();
            Destroy(BossO.gameObject);

        }
    }
}
