using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine;

public class Levelloader : MonoBehaviour
{
    Animator animator;
    public int LevelToBeLoaded;


    private void Awake()
    {
        animator = gameObject.GetComponent<Animator>();
    }

    private void Start()
    {
        animator.Play("FadeIn");
    }

    public void Play()
    {
        LevelToBeLoaded = PlayerPrefs.GetInt("CurrentLevel");
        StartSceneTransition(LevelToBeLoaded);
    }

    public void LoadNextLevel()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
    }

    public void LoadLevel()
    {
        SceneManager.LoadScene(LevelToBeLoaded);
    }

    public void StartSceneTransition(int LV)
    {
        if (SceneManager.GetActiveScene().buildIndex == 0)
        {
            //Ist im Menu, daher sollen bei einem Buttonpress sounds abgespielt werden. 
            FindObjectOfType<Audio_Manager>().Play_("ButtonPress");
        }

        //Wenn man vorher pausiert hat, soll im Menu wieder alles gehen
        Time.timeScale = 1;

        LevelToBeLoaded = LV;
        animator.Play("FadeOut");
    }

    public void StartSceneTransitionButton(int LV)
    {
        FindObjectOfType<Audio_Manager>().Play_("ButtonPress");

        //Wenn man vorher pausiert hat, soll im Menu wieder alles gehen
        Time.timeScale = 1;

        LevelToBeLoaded = LV;
        animator.Play("FadeOut");
    }
}
