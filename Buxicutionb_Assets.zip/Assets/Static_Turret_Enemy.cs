using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Static_Turret_Enemy : MonoBehaviour
{
    public float turretRange, shootCooldown, currentCooldown;
    public GameObject Player, bulletPrefab;

    public Transform SpawnPos1, SpawnPos2;
    public bool isShooting;

    public float bulletSpeed;

    public BulletManager bulletManager;
    public LivesManager livesManager;
    public Animator animator;

    public bool enemyActive = false;
    public float inactiveTime;
    public float camZoomTime;
    CombatRaumManager combatRaumManager;

    public float hitAnimationDuration;

    private void Start()
    {
        currentCooldown = shootCooldown;

        //animaions und spawning
        StartSpawn();
        combatRaumManager = FindObjectOfType<CombatRaumManager>();
        combatRaumManager.EnemySpawned();
        StartCoroutine(WaitAnimationTime());
        StartCoroutine(ActivateEnemy());
    }

    private void Update()
    {
        if(enemyActive)
        {
            if (Vector2.Distance(transform.position, Player.transform.position) < turretRange)
            {
                //The Player is in the range of the turret
            }


            //Shoot
            if (currentCooldown < 0)
            {
                //Shoot
                Shoot();
                currentCooldown = shootCooldown;

            }
            else
            {
                currentCooldown -= Time.deltaTime;
            }
        }
        
    }


    IEnumerator WaitAnimationTime()
    {
        yield return new WaitForSeconds(0.1f); 
        StartShootAnim();
    }

    IEnumerator ActivateEnemy()
    {
        yield return new WaitForSeconds(inactiveTime);

        enemyActive = true;
    }

    //Draw a circle    void OnDrawGizmosSelected()
    void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(transform.position, turretRange);
    }

    void Shoot ()
    {
        GameObject bullet1 = Instantiate(bulletPrefab, SpawnPos1.position, Quaternion.identity);
        GameObject bullet2 = Instantiate(bulletPrefab, SpawnPos2.position, Quaternion.identity);

        turretBullet bulletScript1 = bullet1.GetComponent<turretBullet>();
        turretBullet bulletScript2 = bullet2.GetComponent<turretBullet>();

        bulletScript1.bulletManager = bulletManager;
        bulletScript2.bulletManager = bulletManager;

        bulletScript1.livesManager = livesManager;
        bulletScript2.livesManager = livesManager;

        Rigidbody2D rb1 = bullet1.GetComponent<Rigidbody2D>();
        Rigidbody2D rb2 = bullet2.GetComponent<Rigidbody2D>();

        Vector2 dir1 = new Vector2(0, 0);
        Vector2 dir2 = new Vector2(0, 0);

        dir1 = (SpawnPos1.position - gameObject.transform.position);        
        dir2 = (SpawnPos2.position - gameObject.transform.position);

        rb1.AddForce(dir1.normalized * bulletSpeed);
        rb2.AddForce(dir2.normalized * bulletSpeed);

    }


    void StartSpawn ()
    {
        animator.Play("Turret_Spawn");
    }

    void StartShootAnim()
    {
        animator.Play("Turret_Blink");
    }

    public void StartHit()
    {
        animator.Play("Turret_Hit");

        StartCoroutine(waitAfterHit());
    }

    IEnumerator waitAfterHit()
    {
        yield return new WaitForSeconds(hitAnimationDuration);

        StartShootAnim();
    }


}
