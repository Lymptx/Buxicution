using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine;

public class BulletManager : MonoBehaviour
{
    [Header("Referenzen")]
    public GameObject ShieldPrefab;
    public GameObject BulletPrefab;
    public LayerMask BulletLayer;

    [Header("Einstellungen")]
    public bool isInFirstLevelWithoutShield;
    public float PewPewSpeed;
    public float PewPewRespawnTime;
    public float ShootSpeed;

    Player_Movement player_Movement;
    public bool hasShield = true;

    public LivesManager livesManager;
    public float schildEnergyCost;



    private void Start()
    {
        player_Movement = gameObject.GetComponent<Player_Movement>();
    }

    private void Update()
    {
        if (hasShield)
        {
            if (Input.GetKeyDown(KeyCode.Mouse0))
            {
                if (SceneManager.GetActiveScene().buildIndex != 0)
                {
                    //Position und Rotation von Shield speichern
                    Vector3 position = gameObject.transform.GetChild(0).gameObject.transform.position;
                    Quaternion rotation = gameObject.transform.GetChild(0).gameObject.transform.rotation;

                    //neue Bullet instantiaten                
                    GameObject newBullet = Instantiate(BulletPrefab, gameObject.transform);

                    //Position und Rotation von neuem Bullet anpassen
                    newBullet.transform.position = position;
                    newBullet.transform.rotation = rotation;

                    //Bullet abschie�en
                    newBullet.GetComponent<Rigidbody2D>().velocity = player_Movement.lookDir * ShootSpeed;

                    //altes Schild l�schen
                    DestroyShield();
                    StartNewShieldCorutine();
                }
            }
        }
    }

    public void StartNewShieldCorutine()
    {
        if(!isInFirstLevelWithoutShield) ///Damit man ganz am Anfang vom Spiel noch kein Schild bekommen kann.
        {
            //Remove energy from the player
            livesManager.selfdemage = true;
            livesManager.ChangePlayerLives(-schildEnergyCost);
            livesManager.selfdemage = false;

            StartCoroutine(WaitForNewShield(PewPewRespawnTime));
        }
        
    }

    public IEnumerator WaitForNewShield(float waittime)
    {
        yield return new WaitForSeconds(waittime);
        GetNewShield();
    }

    void GetNewShield()
    {
        //Instantiate(ShieldPrefab, gameObject.transform);
        gameObject.transform.GetChild(0).gameObject.SetActive(true);
        hasShield = true;

        //Sound
        FindObjectOfType<Audio_Manager>().Play_("ShieldRegen");
    }

    public void DestroyShield()
    {
        //Destroy(gameObject.transform.GetChild(0).gameObject, 0);
        gameObject.transform.GetChild(0).gameObject.SetActive(false);
        hasShield = false;
    }


    public void ActivateShieldInFirstLevel ()
    {
        isInFirstLevelWithoutShield = false;

        GetNewShield(); //Nicht die Coroutine starten, weil es nicht warten soll, wenn man das Schild bekommt. 

    }



}
