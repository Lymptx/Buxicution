using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Audio;
using UnityEngine.UI;

public class SettingsManager : MonoBehaviour
{
    public AudioMixer musicMixer;
    public AudioMixer sfxSlider;
    public Text difficultyText;

    public int difficltySetting; //1> simple, 2> normal, 3> nightmare 



    public void ChangeDifficultySettingsUp ()
    {
        FindObjectOfType<Audio_Manager>().Play_("ButtonPress");

        if(difficltySetting == 3) 
        {
            difficltySetting = 1;
        } else
        {
            difficltySetting++;
        }

        ActuallyChangeDifficulty();
    }

    public void ChangeDifficultySettingsDown()
    {
        FindObjectOfType<Audio_Manager>().Play_("ButtonPress");        


        if (difficltySetting == 1)
        {
            difficltySetting = 3;
        } else
        {
            difficltySetting--;
        }

        ActuallyChangeDifficulty();
    }

    public void ActuallyChangeDifficulty()
    {
        if (difficltySetting == 1)
        {
            difficultyText.text = "simple";
            PlayerPrefs.SetInt("Difficulty", 1);
        }

        if (difficltySetting == 2)
        {
            difficultyText.text = "normal";
            PlayerPrefs.SetInt("Difficulty", 2);
        }

        if (difficltySetting == 3)
        {
            difficultyText.text = "nightmare";
            PlayerPrefs.SetInt("Difficulty", 3);
        }
    }

    public void SetMusicVolume(float volume)
    {
        musicMixer.SetFloat("volume_", volume);

        
    }

    public void SetSFXVolume(float volume)
    {
        sfxSlider.SetFloat("soundsvolume", volume);
    }
}
